
import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

import NavegacionPrincipal from "./src/Vista/Navegacion/NavegacionPrincipal"



export default function App() {
  return (
    <NavegacionPrincipal/>
  );
}
