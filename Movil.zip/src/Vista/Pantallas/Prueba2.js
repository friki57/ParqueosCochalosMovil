import React, { Component } from "react";
import { View,  Text, Alert } from 'react-native';


export default class Pruebas extends Component {
  render()
  {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Prueba2</Text>
      </View>
    );
  }
}
