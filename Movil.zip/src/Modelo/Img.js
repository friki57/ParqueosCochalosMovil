export default {
  BarrancaAbajo: require("./../../Assets/Img/BarrancaAbajo.jpg"),
  Porfiado: require("./../../Assets/Img/Porfiado.jpg"),
  Raro: require("./../../Assets/Img/Raro.jpg"),
  Contacto: require("./../../Assets/Img/contactanos.jpg"),
  Mapas: require("./../../Assets/Img/mapasInteractivos2.png"),
  QuienesSomos: require("./../../Assets/Img/QuienesSomos.jpeg"),
  Logo: require("./../../Assets/Img/marca.jpg"),
  Marca: require("./../../Assets/Img/marca.svg"),
  IconoUsuario: require("./../../Assets/Img/IconoUsuario.png"),
  IconoHistorial: require("./../../Assets/Img/IconoHistoria.png"),
  IconoTelefono: require("./../../Assets/Img/IconoTelefono.jpg")
};
