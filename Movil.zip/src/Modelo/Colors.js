export default {
  primary: '#1292B4',
  white: '#FFF',
  lighter: '#F3F3F3',
  light: '#DAE1E7',
  dark: '#444',
  black: '#000',
  customColor: '#F035E0',
  red: '#F8262F',
  blue: '#428AF8',
  silver: '#BEBEBE',
  black2: '#101010',
  white2: '#ebebeb',
  appPrimary: '#4DCA77',
  azul: "#0B313F"

}
